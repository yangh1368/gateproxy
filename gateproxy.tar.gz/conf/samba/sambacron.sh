# #!/bin/bash
echo "Agregando tareas samba al crontab"
sudo crontab -l | { cat; echo '@weekly find /home/tu_smbd/compartida/recycle/* -mtime +7 -exec rm -rf "{}" \; >/dev/null'; } | sudo crontab -
sudo crontab -l | { cat; echo "@daily grep smbd_audit /var/log/syslog > /var/www/html/smbdaudit/smbdaudit.log"; } | sudo crontab -
sudo crontab -l | { cat; echo "@weekly cat /dev/null > /var/www/html/smbdaudit/smbdaudit.log"; } | sudo crontab -
echo OK
