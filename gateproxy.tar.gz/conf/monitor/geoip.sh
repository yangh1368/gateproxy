#!/bin/bash
### BEGIN INIT INFO
# Provides:          geoip update
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
### END INIT INFO
#
# update-geoip.sh actualiza los ficheros .dat de geoip para ntopng
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
# # Functions
# ==========================================================================
#
#
uso() {
echo -n "`basename $0`, v"
echo -n $version | awk '{printf $3}'
echo ". By Luis Palacios"
echo "Actualizado por Maravento.com"
echo "Uso: update-geoip.sh [-h]"
echo " -h help"
echo " "
echo " "
exit -1 # Salimos
}

# Analisis de las opciones
while getopts "h" Option
do
case $Option in

# EOM, no comments
h ) uso;;

# Resto de argumentos, error.
* ) uso;;

esac
done

#
# ================================================================
#
echo

#
cd /usr/share/ntopng/httpdocs/geoip
wget -nc http://geolite.maxmind.com/download/geoip/database/GeoLiteCity.dat.gz
gunzip -f GeoLiteCity.dat.gz

#
cd /usr/share/ntopng/httpdocs/geoip
wget -nc http://geolite.maxmind.com/download/geoip/database/GeoLiteCityv6-beta/GeoLiteCityv6.dat.gz
gunzip -f GeoLiteCityv6.dat.gz

#
cd /usr/share/ntopng/httpdocs/geoip
wget -nc http://download.maxmind.com/download/geoip/database/asnum/GeoIPASNum.dat.gz
gunzip -f GeoIPASNum.dat.gz

#
cd /usr/share/ntopng/httpdocs/geoip
wget -nc http://download.maxmind.com/download/geoip/database/asnum/GeoIPASNumv6.dat.gz
gunzip -f GeoIPASNumv6.dat.gz

# log
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Geoip-Ntopngp: ejecucion $date |-->" >> /var/log/alert.log
