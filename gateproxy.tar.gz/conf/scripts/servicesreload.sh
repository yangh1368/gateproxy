#!/bin/bash
### BEGIN INIT INFO
# Provides:          services reload
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
# By Alterserv.com and Maravento.com
### END INIT INFO
#
# VBOXWEBSERV
#
# Webmin service
	date=`date +%d/%m/%Y" "%H:%M:%S`
	if [[ `ps -A | grep miniserv.pl` != "" ]];then
	echo -e "\nONLINE"
	else
	echo -e "\n"
	service webmin start
	echo "<--| Webmin fue iniciado $date |-->" >> /var/log/alert.log
	fi
#
# DHCP service
	date=`date +%d/%m/%Y" "%H:%M:%S`
	if [[ `ps -A | grep dhcpd` != "" ]];then
	echo -e "\nONLINE"
	else
	echo -e "\n"
	/etc/init.d/leases.sh
	echo "<--| DHCP fue iniciado $date |-->" >> /var/log/alert.log
	fi
#
# Apache2 service
	date=`date +%d/%m/%Y" "%H:%M:%S`
	if [[ `ps -A | grep apache2` != "" ]];then
	echo -e "\nONLINE"
	else
	echo -e "\n"
	service apache2 start
	echo "<--| Apache2 fue iniciado $date |-->" >> /var/log/alert.log
	fi
#
# Squid Service
	date=`date +%d/%m/%Y" "%H:%M:%S`
	if [[ `ps -A | grep squid` != "" ]];then
	echo -e "\nONLINE"
	else
	echo -e "\n"
	service squid start
	echo "<--| Squid fue iniciado $date |-->" >> /var/log/alert.log
	fi
#
# VBOXWEBSERV
