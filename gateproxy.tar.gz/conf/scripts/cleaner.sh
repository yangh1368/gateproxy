#!/bin/bash
### BEGIN INIT INFO
# Provides:          Cleaner
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon
# Author:	     Maravento.com and Novatoz.com
# Contribution:      Lagg3r's Blog
#                    http://www.lagg3r.com.ar/buscar-y-eliminar-archivos-por-consola-bash/
#                    http://geekland.eu
# Execution:         cd $HOME && touch nombredelscript.sh && chmod +x nombredelscrip.sh
### END INIT INFO

# Nomenclatura
# Comando find se le indica la ruta de búsqueda
# (.) representa al directorio actual, pero puede ser cualquiera.
# Opcion -type f para buscar archivos
# Opción -name (“”) va el nombre del archivo a buscar. Se admiten expresiones regulares, como (*) 
# Opcion -exec rm -f {} \; para eliminar archivos
# Opcion -exec mv -f {} \; para mover archivos

# Ejemplos Prácticos

# Buscar y eliminar archivos con el comando find
# find . -type f -name "ARCHIVO-A-BUSCAR"-exec rm -f {} \;

# Buscar y eliminar archivos y directorios con el comando find
# find . -name "ARCHIVO-A-BUSCAR" -exec rm -rf {} \;

# Buscar archivos Thumbs.db en el directorio actual (.) y eliminarlos
# find . -type f -name "Thumbs.db" -exec rm -f {} \;

# Buscar archivos core en el sistema (/) y eliminarlos:
# find / -name core -exec rm -f {} \;

# Buscar archivos .bak en el directorio actual (.) y eliminarlos solicitando confirmación:
# find . -type f -name "*.bak" -exec rm -i {} \;

# Eliminar todos los archivos y conservar .mp3:
# find . ! -name "*.mp3" -exec rm -f {} \;

# Buscar archivos con extensión .xxx y copiarlos a otra carpeta.
# find /home/User/Carpeta/ -regextype posix-egrep -regex '^.*\.(png|jpg)$' -exec cp {} /Destino/ \;

# Buscar archivos con extensión .xxx y moverlos a otra carpeta.
# find /home/User/Carpeta/ -regextype posix-egrep -regex '^.*\.(png|jpg)$' -exec mv {} /Destino/ \;

# Mover archivos mp3 y mp4 masivamente de una carpeta a otra.
# find /home/usuario/compartida/ -regextype posix-egrep -regex '^.*\.(mp4|mp3)$' -exec mv {} /home/usuario/musica/ \;

# Mover archivos.ext de un lugar a otro
# find directorio_origen -type f -name *.EXT -exec mv {} ./directorio_destino \;

# Para mover (o copiar, cambiar mv por cp):
# find /Directorio/ -iname "juno*" | xargs -i mv {}/Dirección donde se quiere mover/

# Para borrar
# find /Directorio -iname "archivo"-exec rm {} \;
# find / -iname "nombredelarchivo*" | xargs -i mv {} /destino
# find /ruta -iname "*referencia*" -type f -exec mv /destino {} \;

# Buscar y mover de forma recursiva
# find _origindir_ -type f -name ”_pattern_” -exec mv -v {} _outputdir_ ;

# Buscar y eliminar archivos ADS (Thumbs.db, Zone.identifier, encryptable, etc)
#find . -type f -name "Nombre_del_Archivo" -exec rm {} \;
find . -type f -regextype posix-egrep -iregex "^.*(:encryptable|Zone\.identifier|goutputstream|Thumbs\.db|attributes:).*$" -exec mv -f {} ~/.local/share/Trash/files \;

# Eliminar reportes antiguos de apport
rm -f /var/crash/*crash

# Vaciar la Swap
swapoff -a && swapon -a

# Sincronizar y vaciar la RAM
sync && sysctl -w vm.drop_caches=3 vm.swappiness=20

# log registry
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Cleaner: ejecucion $date |-->" >> /var/log/alert.log
