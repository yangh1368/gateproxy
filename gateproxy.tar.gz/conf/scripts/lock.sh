#!/bin/bash
### BEGIN INIT INFO
# Provides:          lock
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
# by http://jose-linares.com/
### END INIT INFO
randa=$(($RANDOM%3+1))
pid_ejecutando=$(ps -eo pid,comm | grep $0 | egrep -o '[0-9]+' )
if [[ "${pid_ejecutando:-NO_VALUE}" != "NO_VALUE" ]] ; then
   echo "$0 $@" | at now + $randa min
   exit
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Lock: ejecucion $date |-->" >> /var/log/alert.log
fi
