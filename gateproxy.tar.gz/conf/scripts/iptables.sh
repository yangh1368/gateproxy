#!/bin/bash
### BEGIN INIT INFO
# Provides:          iptables
# Required-Start:    $remote_fs $syslog $network
# Required-Stop:     $remote_fs $syslog $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       iptables for gateproxy project
# Authors:           Maravento.com and Novatoz.com
# Execute:           chmod +x /etc/init.d/iptables.sh
# Verify:            iptables -L -n o iptables -nvL
# Ports Verify:      /etc/services
# Thanks to:         a lot of sources and people
# Grafic:			 Puede ver su iptables graficamente en 
#					 http://jekor.com/gressgraph/
# Ports:			https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.txt
### END INIT INFO
#-------------------------------------------------------

echo FIREWALL START

#################################
### FIREWALL AND KERNEL RULES ###
#################################

echo Load Firewall ans Kernel Rules. Wait...

internet=eth0
lan=eth1
local=192.168.0.0
iptables=/sbin/iptables
ip6tables=/sbin/ip6tables
route=/etc/acl
proxyport1=3128
proxyport2=8080
netmask=24
serverip="$(ip addr show eth1 | grep 'inet ' | cut -f2 | awk '{ print $2}')"
# sysadmin mac
sysadmin="00:00:00:00:00:00"

echo ok

#######################
### ESSENTIAL RULES ###
#######################

echo Load Essential Rules...

# Zero all packets and counters
$iptables -F
$iptables -X
$iptables -t nat -F
$iptables -t nat -X
$iptables -t mangle -F
$iptables -t mangle -X
$iptables -t raw -F
$iptables -t raw -X
$iptables -t security -F
$iptables -t security -X
$iptables -Z
$iptables -t nat -Z
$iptables -t mangle -Z

# Preload required kernel modules
# modules (consulte con lsmod)
modprobe=/sbin/modprobe
arp=/usr/sbin/arp
# Adicional modules
sysctl=/sbin/sysctl
rmmod=/sbin/rmmod
lsmod=/sbin/lsmod
depmod=/sbin/depmod
grep=/bin/grep
awk=/usr/bin/awk

# modprobe
# ls /lib/modules/*/kernel/net/*/netfilter/
$modprobe ip_tables
$modprobe iptable_nat
$modprobe iptable_mangle
$modprobe iptable_filter
$modprobe ipt_state
$modprobe ipt_REJECT
$modprobe nf_nat
$modprobe nf_conntrack
$modprobe ip_conntrack
$modprobe ip_conntrack_ftp
$modprobe ip_conntrack_irc
$modprobe nf_conntrack_ipv4
$modprobe nf_conntrack_ftp
$modprobe xt_connlimit
$modprobe ipt_recent
$modprobe xt_NFLOG
$modprobe tun

echo OK

##################################
## POLICIES AND ESSENTIAL RULES ##
##################################

echo Load Policies and Essential Rules. Wait...


# Global Policies (DROP or ACCEPT)
$iptables -P INPUT DROP
$iptables -P OUTPUT ACCEPT
$iptables -P FORWARD ACCEPT
$iptables -t nat -P PREROUTING ACCEPT
$iptables -t nat -P POSTROUTING ACCEPT
$iptables -t nat -P OUTPUT ACCEPT
$iptables -t mangle -P PREROUTING ACCEPT
$iptables -t mangle -P INPUT ACCEPT
$iptables -t mangle -P FORWARD ACCEPT
$iptables -t mangle -P OUTPUT ACCEPT
$iptables -t mangle -P POSTROUTING ACCEPT

# LOOPBACK
$iptables -A INPUT -p all -i lo -j ACCEPT
$iptables -A INPUT -s 192.168.0.10 -j ACCEPT
$iptables -A OUTPUT -p all -o lo -j ACCEPT
$iptables -A OUTPUT -p all -s 127.0.0.1 -j ACCEPT
$iptables -t mangle -A PREROUTING -p all -i lo -j ACCEPT
$iptables -t mangle -A PREROUTING -p all -s 127.0.0.1 -j ACCEPT
$iptables -t nat -A PREROUTING -p all -i lo -j ACCEPT

# IP forward rules (El resto de las reglas en /etc/sysctl.conf)
echo 1 > /proc/sys/net/ipv4/ip_forward

# ACCESS TO LOCAL NETWORK
# path dhcpd.conf/ips_dhcp/macs_dhcp.txt
dhcp_conf=/etc/dhcp/dhcpd.conf
# path ips-macs dhcp
path_ips=/etc/acl/ips_dhcp.txt
path_macs=/etc/acl/macs_dhcp.txt
# mac2ip
mac2ip=$(sed -n '/^\s\+hardware\|^\s\+fixed/ s:hardware ethernet \|fixed-address ::p' $dhcp_conf | sed 's/;//')
create_acl() {
    ips="# ips"
    macs="# macs"
    while [ "$1" ]; do
        mac="$1"
        shift
        ip="$1"
        shift
        $iptables -t mangle -A PREROUTING -i $lan -m mac --mac-source $mac -s $ip -j ACCEPT
        ips="$ips\n$ip"
        macs="$macs\n$mac"
    done
    echo $ips > $path_ips
    echo $macs > $path_macs
}
create_acl $mac2ip
$iptables -t mangle -A PREROUTING -i $lan -j DROP

# Abriendo puertos para Sysadmin (ALLOW SSH, WEBMIN, NTOP, NetUSB)
$iptables -A INPUT -i $lan -m mac --mac-source $sysadmin -p tcp -m multiport --dports 22,23,3000,1194,5000,10000,20005 -j ACCEPT

# Cerrando puertos sensibles (excluya o incluya los que necesite)
$iptables -A INPUT -p tcp -m multiport --dports 22,23,1080,1723,3000,3306,5000,5432,5900,6001,10000,20005 -j DROP
$iptables -A INPUT -p udp -m multiport --dports 22,23,1080,1723,3000,3306,5000,5432,5900,6001,10000,20005 -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 445 -j DROP

# Cerrando well-known ports en interfaz publica (Puede generar falsos positivos)
#$iptables -A INPUT -i $internet -p tcp --dport 1:1024 -j NFLOG --nflog-prefix 'Illegal Access: tcp 1:1024'
#$iptables -A INPUT -i $internet -p tcp --dport 1:1024 -j DROP
#$iptables -A INPUT -i $internet -p udp --dport 1:1024 -j NFLOG --nflog-prefix 'Illegal Access: udp 1:1024'
#$iptables -A INPUT -i $internet -p udp --dport 1:1024 -j DROP

# Abriendo puertos en interface externa (solo activelos si realmente los necesita)
# abriendo puertos NETBios (137,138,139), Bootstrap Protocol Server (67,68), Multicast DNS (5353) y DNS 53
#$iptables -A INPUT -i $internet -p tcp -m multiport --dports 67,68,137,138,139,53,5353 -j ACCEPT
#$iptables -A INPUT -i $internet -p udp -m multiport --dports 67,68,137,138,139,53,5353 -j ACCEPT

# TERMINALS UNRESTRICTED (Macs include within acl macsprivilegiadas)
for mac in `awk -F";" '{print $2}' $route/macsprivilegiadas.txt`; do
 $iptables -t nat -A PREROUTING -i $lan -m mac --mac-source $mac -j ACCEPT
 $iptables -A FORWARD -i $lan -m mac --mac-source $mac -p tcp -j ACCEPT
done

echo OK

################
## EDGE RULES ##
################
# FIRST LINE DEFENCE BETWEEN PERIMETER AND HOST-BASED SECURITY

echo Load Edge Rules. Wait...

# BLACKZONE (select country to block and ip/range)
# http://www.ipdeny.com/ipblocks/
ipset=/sbin/ipset
$ipset -F
$ipset -N -! blackzone hash:net maxelem 1000000
# Descomente esta linea si desea bloquear paises enteros
#for ip in $(cat /etc/zones/{cn,ru}.zone /etc/acl/blackip); do
# Descomente esta linea si desea bloquear solo ips (recomendado)
for ip in $(cat /etc/acl/blackip.txt); do
 $ipset -A blackzone $ip
done
$iptables -A FORWARD -m set --match-set blackzone dst -j DROP
$iptables -t mangle -A PREROUTING -m set --match-set blackzone src -j DROP

# Acceso ilegal al servidor
# Log: /var/log/ulog/syslogemu.log
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/passwd" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /etc/passwd'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/passwd" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/shadow" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /etc/shadow'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/shadow" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/group" --algo kmp  -j NFLOG --nflog-prefix 'Illegal Access: /etc/group'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/group" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/var/lib/mysql" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /var/lib/mysql'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/var/lib/mysql" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/apache2" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /etc/apache2'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/apache2" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/squid" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /etc/squid'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/squid" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/var/log" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /var/log'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/var/log" --algo kmp -j DROP
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/init.d" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /etc/init.d'
$iptables -t mangle -A PREROUTING -i $internet -m string --string "/etc/init.d" --algo kmp -j DROP
# Puede generar falsos positivos
#$iptables -A INPUT -i $internet -m string --string "/root" --algo kmp -j NFLOG --nflog-prefix 'Illegal Access: /root'
#$iptables -A INPUT -i $internet -m string --string "/root" --algo kmp -j DROP

# Block spoofed packets
for ip in `sed '/#.*/d' $route/ipsreservadas.txt`; do
    $iptables -t mangle -A PREROUTING -s 127.0.0.1 -i lo -j ACCEPT
    $iptables -t mangle -A PREROUTING -i $internet -s $ip -j NFLOG --nflog-prefix "IP SPOOF"
    $iptables -t mangle -A PREROUTING -i $internet -s $ip -j DROP
done

# Block Bypassing Firewalls with IPv6 over IPv4 (6to4) Tunnels
# http://www.iana.org/assignments/ipv6-multicast-addresses/
# https://www.ietf.org/rfc/rfc7123.txt
$iptables -t mangle -A PREROUTING -p tcp -m multiport --dports 41,43,44,58,59,60,3544 -j NFLOG --nflog-prefix 'Illegal Access: 6to4'
$iptables -t mangle -A PREROUTING -p tcp -m multiport --dports 41,43,44,58,59,60,3544 -j DROP
$iptables -I FORWARD 1 -p udp --dport 1024: -m string --hex-string "|ff020000000000000000000000000002|" --algo bm -j NFLOG --nflog-prefix 'Illegal Access: 6to4 String'
$iptables -I FORWARD 1 -p udp --dport 1024: -m string --hex-string "|ff020000000000000000000000000002|" --algo bm -j DROP
# Block default anycast address of some 6to4 systems
$iptables -t mangle -A PREROUTING -s 192.88.99.1 -j NFLOG --nflog-prefix 'Illegal Access: default anycast 6to4'
$iptables -t mangle -A PREROUTING -s 192.88.99.1 -j DROP

# Block wpad attack
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 80 -m string --to 70 --algo bm --string "GET /wpad.dat" -j NFLOG --nflog-prefix "Wpad poison"
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 80 -m string --to 70 --algo bm --string "GET /wpad.dat" -j REJECT --reject-with tcp-reset
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 80 -m string --to 70 --algo bm --string "GET /wpad.da" -j NFLOG --nflog-prefix "Wpad poison"
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 80 -m string --to 70 --algo bm --string "GET /wpad.da" -j REJECT --reject-with tcp-reset

# Protect DNS Amplification Attack
$iptables -t mangle -A PREROUTING -i $internet -p udp --dport 53 -m string --from 50 --algo bm --hex-string '|0000FF0001|' -m recent --set --name dnsanyquery
$iptables -t mangle -A PREROUTING -i $internet -p udp --dport 53 -m string --from 50 --algo bm --hex-string '|0000FF0001|' -m recent --name dnsanyquery --rcheck --seconds 60 --hitcount 3 -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p udp --dport 53 -m string --from 50 --algo bm --hex-string '|0000FF0001|' -j DROP
# Protect isc.org Attack
$iptables -t mangle -A PREROUTING -i $internet -p udp -m string --hex-string "|03697363036f726700|" --algo bm --to 65535 -j DROP

# ANTI-DDOS RULES
# string ptrxcz
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 80 -m string --string "ptrxcz" --algo bm -j NFLOG --nflog-prefix 'Illegal DDos: ptrxcz'
$iptables -t mangle -A PREROUTING -i $internet -p tcp --dport 80 -m string --string "ptrxcz" --algo bm -j DROP
# Drop invalid packets
$iptables -t mangle -A PREROUTING -i $internet -m conntrack --ctstate INVALID -j DROP
# Drop TCP packets that are new and are not SYN
$iptables -t mangle -A PREROUTING -i $internet -p tcp ! --syn -m conntrack --ctstate NEW -j DROP
# Drop SYN packets with suspicious MSS value
$iptables -t mangle -A PREROUTING -i $internet -p tcp -m conntrack --ctstate NEW -m tcpmss ! --mss 536:65535 -j DROP
# Block packets with bogus TCP flags
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG NONE -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags FIN,SYN FIN,SYN -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags SYN,RST SYN,RST -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags FIN,RST FIN,RST -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags FIN,ACK FIN -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ACK,URG URG -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ACK,FIN FIN -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ACK,PSH PSH -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ALL ALL -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ALL NONE -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ALL FIN,PSH,URG -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ALL SYN,FIN,PSH,URG -j DROP
$iptables -t mangle -A PREROUTING -i $internet -p tcp --tcp-flags ALL SYN,RST,ACK,FIN,URG -j DROP
# Drop fragments in all chains
$iptables -t mangle -A PREROUTING -i $internet -f -j DROP
# Limit connections per source IP
$iptables -A INPUT -i $internet -p tcp -m connlimit --connlimit-above 111 -j REJECT --reject-with tcp-reset
# Limit RST packets
$iptables -A INPUT -i $internet -p tcp --tcp-flags RST RST -m limit --limit 2/s --limit-burst 2 -j ACCEPT
$iptables -A INPUT -i $internet -p tcp --tcp-flags RST RST -j DROP
# Limit new TCP connections per second per source IP
$iptables -A INPUT -i $internet -p tcp -m conntrack --ctstate NEW -m limit --limit 60/s --limit-burst 20 -j ACCEPT
$iptables -A INPUT -i $internet -p tcp -m conntrack --ctstate NEW -j DROP
# SSH brute-force protection
$iptables -A INPUT -i $internet -p tcp --dport ssh -m conntrack --ctstate NEW -m recent --set
$iptables -A INPUT -i $internet -p tcp --dport ssh -m conntrack --ctstate NEW -m recent --update --seconds 60 --hitcount 10 -j DROP
# Recent http
$iptables -A INPUT -p tcp -m state --state NEW --dport 80 -m recent --update --seconds 15 --hitcount 10 -j DROP

echo OK

####################
## SECURITY RULES ##
####################

echo Load Security Rules. Wait...

# PORT SCAN RULES
# Scan block DFind w00tw00t.at.ISC.SANS
$iptables -t mangle -A PREROUTING -p tcp --dport 80 -m string --to 70 --algo bm --string 'GET /w00tw00t.at.ISC.SANS.' -j DROP 
$iptables -t mangle -A PREROUTING -p tcp --dport 80 -m string --to 60 --algo bm --string 'GET /w00tw00t' -j DROP
# Protection against port scanning
$iptables -N port-scanning
$iptables -I port-scanning -i $internet -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s --limit-burst 2 -j RETURN
$iptables -I port-scanning -j NFLOG --nflog-prefix "portscan"
$iptables -I port-scanning -j DROP
# Anti portscan (24 H block. seconds 86400). After that remove block  (CAMBIA A 300 SEGUNDOS PARA PROBAR)
$iptables -I INPUT -m recent --name portscan --rcheck --seconds 300 -j NFLOG --nflog-prefix "portscan"
$iptables -I INPUT -m recent --name portscan --rcheck --seconds 300 -j DROP
$iptables -I INPUT -m recent --name portscan --removeP

# Drop ICMP (PING)
$iptables -t mangle -A PREROUTING -p icmp -j DROP

# Blackstring Project
# Log: /var/log/ulog/syslogemu.log
for string in `sed '/#.*/d' $route/blackstring.txt`; do
  $iptables -I FORWARD -m string --hex-string "|$string|" --algo kmp -j NFLOG --nflog-prefix 'Illegal Anonymizer'
  $iptables -I FORWARD -m string --hex-string "|$string|" --algo kmp -j DROP
done

echo OK

#########################
## LOCAL NETWORK RULES ##
#########################

echo Load Network Rules. Wait...

# ENMASCARAMIENTO DE RED LAN (COMPARTIR INTERNET CON LAN)
$iptables -t nat -A POSTROUTING -s $local/$netmask -o $internet -j MASQUERADE

# CONEXIONES PREESTABLECIDAS
# LAN ---> PROXY <--- INTERNET
$iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
$iptables -A OUTPUT -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
$iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT
# Rechazar conexiones nuevas no solicitadas
$iptables -A INPUT -i $internet -m state --state NEW -j NFLOG --nflog-prefix 'Illegal: state NEW'
$iptables -A INPUT -i $internet -m state --state NEW -j DROP

# DNS-LOCAL


# DNS-PUBLIC


for ip in $dns; do
 $iptables -A OUTPUT -d $ip -o $internet -p udp --dport 53 -m state --state ESTABLISHED,RELATED,NEW -j ACCEPT
 $iptables -A INPUT -s $ip -i $internet -p udp --sport 53 -m state --state ESTABLISHED -j ACCEPT
 $iptables -A FORWARD -s $local/$netmask -i $lan -p udp --dport 53 -d $ip -o $internet -m state --state ESTABLISHED,RELATED,NEW -j ACCEPT
done

# WELL-KNOWN PORTS (Active los puertos que necesite)
# FTP
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp --dport 20:21 -j ACCEPT
#$iptables -A INPUT -s $local/$netmask -i $lan -p udp --dport 20:21 -j ACCEPT
# SMTP/SSMTP
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp -m multiport --dports 25,465,587 -j ACCEPT
# POP3PASS
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp --dport 106 -j ACCEPT
# POP3/POP3S
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp -m multiport --dports 110,995 -j ACCEPT
# IMAP/IMAPS
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp -m multiport --dports 143,993 -j ACCEPT
# Admin Panels (Plesk/DirectAdmin)
#$iptables -A INPUT -s $local/$netmask -i $lan -m multiport --dports 2222,8443 -j ACCEPT
# Open cups (printing service) udp/tcp for LAN users
#$iptables -A INPUT -s $local/$netmask -i $lan -p udp -m udp --dport 631 -j ACCEPT
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp -m tcp --dport 631 -j ACCEPT
# NTP (allow time sync via NTP)
#$iptables -A INPUT -s $local/$netmask -i $lan -m state --state NEW -p udp --dport 123 -j ACCEPT
#$iptables -A OUTPUT -s $local/$netmask -p tcp -m multiport --dports 37,123 -j ACCEPT
#$iptables -A OUTPUT -s $local/$netmask -p udp --dport 123 -j ACCEPT
# MySQL
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp --dport 3306 -j ACCEPT
#$iptables -A OUTPUT -s $local/$netmask -p tcp --dport 3306 -j ACCEPT
# PostgreSQL
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp --dport 5432 -j ACCEPT
#$iptables -A OUTPUT -s $local/$netmask -p tcp --dport 5432 -j ACCEPT
# PPTPD
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp --dport 1723 -j ACCEPT
# Open VPN
#$iptables -A INPUT -s $local/$netmask -i $lan -p tcp --dport 1194 -j ACCEPT
#$iptables -A OUTPUT -s $local/$netmask -p tcp --dport 1194 -j ACCEPT
# VNC
#$iptables -A INPUT -s $local/$netmask -i $lan -m state --state NEW -m tcp -p tcp --dport 5900 -j ACCEPT
#$iptables -A INPUT -s $local/$netmask -i $lan -m state --state NEW -m tcp -p tcp --dport 5901 -j ACCEPT
# MONITORIX


# SAMBA


# IPTRAF


# bandwidthd


# SARG


# PHPVIRTUALBOX


echo ok

#################
## PROXY RULES ##
#################

echo Load Proxy Rules. Wait...

# PROXYCACHE no-transparent (proxyport1 3128) and WPAD-PAC (Puerto de divulgacion 8000 - Opcion 252 DHCP)


# PROXYINTERCEPT


echo OK

# DENEGAR EL RESTO
echo Drop All...
$iptables -A FORWARD -s 0.0.0.0/0 -j DROP
$iptables -A INPUT -s 0.0.0.0/0 -j DROP
# End of iptables
echo Done. End of Iptables
