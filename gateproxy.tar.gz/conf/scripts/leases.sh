#!/bin/bash
### BEGIN INIT INFO
# Provides:          leases
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
### END INIT INFO
# By jose-linares, Maravento.com and Novatoz.com

dhcpd=/var/lib/dhcp/dhcpd.leases
dhcpd_temp=/var/lib/dhcp/dhcpd.leases.temp
dhcp_conf=/etc/dhcp/dhcpd.conf
dhcp_conf_temp=/etc/dhcp/dhcpd.conf.temp #$(mktemp)
echo "" > $dhcp_conf_temp

route=/etc/acl

ServDHCP=192.168.0.10
ServIniRangeBlack=192.168.0.100
ServFinRangeBlack=192.168.0.250
ServDHCPBroadcast=192.168.0.255
ServDNS=8.8.8.8,8.8.4.4
#ServDNS=192.168.0.10

function leer_leases
{
	# Lectura de las entradas de dhcp_leases. Formato:
	#	host PC2 {
	# 		hardware ethernet 00:13:46:7a:xx:xx;
	# 		fixed-address 192.168.1.183;
	#	}

	# Formato de salida
	# [a|b];00:11:22:33:44:55;111.111.111.111;nombre_host;fecha_introduccion
	#
	num_linea_actual=0
	while read line; do
		num_linea_actual=$(($num_linea_actual+1))
		if $(echo "$line" | egrep -q 'lease [0-9,.]+ {' ) ; then		# Inicializacion de variables de un nuevo lease
			host="Sin_nombre_$(get_cadena_random 10)";
			direccion_mac="";
			direccion_ip=$(echo "$line" | egrep -o '[0-9,.]+');
			num_linea_inicio_lease=$num_linea_actual
			num_linea_fin_lease=0
			continue
		fi

		if $(echo "$line" | egrep -q 'client-hostname "[^"]+";' ) ; then
			host=$(echo "$line" | cut -d"\"" -f2) ;
			# Si el cliente no tenia nombre asociado, se actualiza su entrada
			if [[ $direccion_mac != "" && $(egrep "$direccion_mac;[^;]+;Sin_nombre_[^;]+;" $route/macs* $route/blackdhcp.txt) != "" ]] ; then
				linea_aux=$(egrep "$direccion_mac;[^;]+;Sin_nombre_[^;]+;" $route/macs* $route/blackdhcp.txt | cut -d":" -f2-)
				WC_STATUS_aux=$(echo $linea_aux | cut -d ';' -f 1)
				MACSOURCE_aux=$(echo $linea_aux | cut -d ';' -f 2)
				IPSOURCE_aux=$(echo $linea_aux | cut -d ';' -f 3)
				FECHA_aux=$(echo $linea_aux | cut -d ';' -f 5)
				sed -i "s/$linea_aux/$WC_STATUS_aux;$MACSOURCE_aux;$IPSOURCE_aux;$host;$FECHA_aux/g" $route/blackdhcp.txt $route/macs*
			fi
			continue
		fi

		if $(echo "$line" | egrep -q 'hardware ethernet [0-9,a-f,:]+;' ) ; then
			direccion_mac=$(echo "$line" | egrep -o '[0-9,a-f,:]+;' | cut -d";" -f1) ;
			continue
		fi

		if $(echo "$line" | egrep -q '}' ) ; then			# Final del lease actual
			fecha=$(date +"%s")
			num_linea_fin_lease=$num_linea_actual
			if [[ $host != ""  && $direccion_mac != "" && $direccion_ip != "" ]] ; then
				linea_lease="a;$direccion_mac;$direccion_ip;$host;$fecha;"
				if [[ $( grep -o $direccion_mac $route/macs* ) == ""  ]] ; then	
					if [[ $( grep -o $direccion_mac $route/blackdhcp.txt ) == "" ]] ; then
						# Si la dirección mac no está en el acl macslocal ni en blackdhcp, se añade a blackdhcp, pero se mantiene en el lease.
						# La proxima vez que se ejecute el script, si sigue en el blackdhcp, no aparecerá en el archivo lease.
						echo $linea_lease >> $route/blackdhcp.txt
						sed "$num_linea_inicio_lease,$num_linea_fin_lease!d" $dhcpd >> $dhcpd_temp
					fi
				else
					# Si esta en macslocal, se añade al leases temporal:
					sed "$num_linea_inicio_lease,$num_linea_fin_lease!d" $dhcpd >> $dhcpd_temp
					echo "" >> $dhcpd_temp # Por formato
				fi
			fi
		fi

	done < $dhcpd

	# Reemplaza el archivo leases actual por el nuevo, en el que solamente están los usuarios de la acl macslocal
	if [[ -e $dhcpd_temp ]] ; then
		mv -f $dhcpd_temp $dhcpd
	else
		echo "" > $dhcpd
	fi
}

function actualizar_dhcp_conf
{
	# Actualización del archivo de configuración con datos de $route/macs* y $route/blackdhcp.txt
	# Opciones generales
# Opciones generales
	echo '# ISC-DHCP-Server Configuration
authoritative;
option pac1 code 252 = text;
option pac2 code 252 = text;
option pac3 code 252 = text;
server-identifier 192.168.0.10;
deny duplicates;
one-lease-per-client true;
deny declines;
deny client-updates;
ping-check true;
log-facility local7;
ddns-update-style none;
'> $dhcp_conf_temp

	# Clientes admitidos en el sistema de la acl local
	for linea in $(cat $route/macs*) ; do
		WC_STATUS=$(echo $linea | cut -d ';' -f 1)
		MACSOURCE=$(echo $linea | cut -d ';' -f 2)
		IPSOURCE=$(echo $linea | cut -d ';' -f 3)
		USUARIO=$(echo $linea | cut -d ';' -f 4)
		if [[ $WC_STATUS == "a" ]]; then
			echo '
	host '$USUARIO '{
	hardware ethernet '$MACSOURCE';
	fixed-address '$IPSOURCE';
	}' >> $dhcp_conf_temp
		fi
    done

	# Clientes bloqueados por encontrarse en la lista negra
	echo '
class "blackdhcp" {
	 match pick-first-value (option dhcp-client-identifier, hardware);
	}' >> $dhcp_conf_temp

  	for linea in $(cat $route/blackdhcp.txt) ; do
  		MACSOURCE=$(echo $linea | cut -d ';' -f 2)
  		echo '	subclass "blackdhcp" 1:'$MACSOURCE';' >> $dhcp_conf_temp
  	done

  	echo "" >> $dhcp_conf_temp

	# Configuracion subred
	echo "
subnet 192.168.0.0 netmask 255.255.255.0 {
	option pac1 \"http://192.168.0.10:8000/proxy.pac\";
	option pac2 \"http://192.168.0.10:8000/wpad.dat\";
	option pac3 \"http://192.168.0.10:8000/wpad.da\";
	option routers 192.168.0.10;
	option subnet-mask 255.255.255.0;
	option broadcast-address 192.168.0.255;
	#option domain-name \"example.org\";
	option domain-name-servers $ServDNS;
	min-lease-time 2592000; # 30 days
	default-lease-time 2592000; # 30 days
	max-lease-time 2592000; # 30 days
	pool {
        min-lease-time 60;
	default-lease-time 60;
	max-lease-time 60;
        deny members of \"blackdhcp\";
	range $ServIniRangeBlack $ServFinRangeBlack;
    }
}
">> $dhcp_conf_temp

mv -f $dhcp_conf_temp $dhcp_conf

}

function limpiar_lista_negra
{
	# Elimina de la lista negra las entradas añadidas al acl macslocal o macsunlimited
	archivo_temp=$(mktemp)
	egrep ';[0-9,a-f,:]+;' $route/macs* | cut -d ";" -f2 > $archivo_temp
	while read linea ; do
		mac_actual=$(echo $linea | cut -d ';' -f 2)
		sed -i "/$mac_actual/d" $route/blackdhcp.txt
	done < $archivo_temp
	rm -f $archivo_temp
}

function limpiar_lista_local
{
	# Elimina de la lista local las entradas añadidas al acl macsunlimited
	while read linea ; do
		mac_actual=$(echo $linea | cut -d ';' -f 2)
		sed -i "/$mac_actual/d" $route/macslocal.txt
	done < $route/macsunlimited.txt
}

function limpiar_acls
{
	# Elimina lineas en blanco de todas las acls
	sed '/^$/d' -i $route/blackdhcp.txt
	sed '/^$/d' -i $route/macslocal.txt
	sed '/^$/d' -i $route/macsunlimited.txt
}

function get_cadena_random
{
	tr -cd 'a-zA-Z0-9' < /dev/urandom | head -c $1
}


function ordenar_archivos_acl
{
	sort -n -t . -k 3,3 -k 4,4 $route/blackdhcp.txt -o $route/blackdhcp.txt
	sort -n -t . -k 3,3 -k 4,4 $route/macslocal.txt -u -o $route/macslocal.txt
	sort -n -t . -k 3,3 -k 4,4 $route/macsunlimited.txt -u -o $route/macsunlimited.txt
}

limpiar_acls
limpiar_lista_negra
limpiar_lista_local

/etc/init.d/isc-dhcp-server stop
leer_leases
ordenar_archivos_acl
actualizar_dhcp_conf
/etc/init.d/isc-dhcp-server start
